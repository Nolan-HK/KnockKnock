﻿//#include "msgProcess.h"
//#include "clientSocket.h"
//#include "util.h"
//
//#include <QTcpSocket>
//#include <QByteArray>
//#include <QTcpSocket>
//#include <QFileInfo>
//#include <QDir>
//
//Process::Process(QObject* parent)
//{
//    
//    //connect(NetworkManager::getInstance(), &NetworkManager::jsonPacketRecevied, [this](QTcpSocket* socket, const QByteArray& data) {
//    //    msgProcess(socket, data);
//    //    });
//}
//
//Process::~Process()
//{
//}
//
//void Process::msgProcess(QTcpSocket* socket, const QByteArray& data)
//{
//    int msg_type = -1;
//    QJsonObject data_ = converToJson(data);
//    msg_type = data_.value("type").toInt();
//
//    switch (msg_type)
//    {
//    case Register:
//    {
//        registerUser(socket, data_);
//    } break;
//    case Login:
//    {
//        login(socket, data_);
//    } break;
//    case searchUserInfo:
//    {
//        searchUser(socket, data_);
//    }   break;
//    default:
//        break;
//    }
//}
//
//QJsonObject Process::converToJson(const QByteArray& data)
//{
//    QJsonParseError jsonError;
//    QJsonObject jsonObj;
//    QJsonDocument doc = QJsonDocument::fromJson(data, &jsonError);
//
//    if (!doc.isNull() && (jsonError.error == QJsonParseError::NoError)) {
//        if (doc.isObject()) {
//            jsonObj = doc.object();
//            return jsonObj;
//        }
//    }
//    else
//    {
//        qDebug() << "解析错误类型：" << jsonError.error;
//        qDebug() << "解析错误信息：" << jsonError.errorString();
//        qDebug() << "错误位置：" << jsonError.offset;
//    }
//    return QJsonObject();
//}
//
//QByteArray Process::converToByteArray(const QJsonObject& data)
//{
//    QJsonDocument doc(data);
//    return doc.toJson();
//}
//
//void Process::registerUser(QTcpSocket* socket, const QJsonObject& dataValue)
//{
//    QString nickname = dataValue.value("nickname").toString();
//    QString passwd = dataValue.value("passwd").toString();
//    QString avatarPath = dataValue.value("avatarPath").toString();
//    //
//    QString avatarByte = dataValue.value("avatarData").toString();
//    QByteArray avatarData = QByteArray::fromBase64(avatarByte.toUtf8());
//    QFileInfo fileInfo(avatarPath);
//    QString avatarName = fileInfo.fileName();
//
//
//    //QJsonObject result = database->RegisterUser(nickname, passwd, avatarName);  //注册结果
//    //注册成功将为用户创建文件夹存放数据
//    if (result.value("status") == OK)
//    {
//        QString uid = result.value("uid").toString();
//        QString savedPath = "recv/" + uid + "/avatar/";
//        QDir dir;
//        if (!dir.exists(savedPath))
//        {
//            dir.mkpath(savedPath);
//        }
//        QFile file(savedPath + avatarName);
//        if (file.open(QIODevice::WriteOnly))
//        {
//            file.write(avatarData);
//            file.close();
//        }
//
//    }
//    //构造并回传消息
//    QJsonDocument doc(result);
//    msgReply(socket, doc.toJson(), noFile);
//}
//
//void Process::login(QTcpSocket* socket, const QJsonObject& dataValue)
//{
//    QString uid = dataValue.value("uid").toString();
//    QString passwd = dataValue.value("passwd").toString();
//    //QJsonObject result = database->Login(uid, passwd);
//    //构造并回传消息
//    //QJsonDocument doc(result);
//    //msgReply(socket, doc.toJson(), noFile);
//}
//
//void Process::searchUser(QTcpSocket* socket, const QJsonObject& dataValue)
//{
//    QString uid = dataValue.value("uid").toString();
//    //QJsonObject result = database->getUserInfo(uid);
//    
//    //int status = result.value("status").toInt();
//    //获取头像路径，在服务端本地查找，回传给客户端
//    if (status == OK)
//    {
//        QString avatarPath = "recv/" + uid + "/avatar/" + result.value("avatarName").toString();
//        QFile file(avatarPath);
//        if (file.open(QIODevice::ReadOnly))
//        {
//            QByteArray fileData = file.readAll();
//            file.close();
//
//            QString base64Data = fileData.toBase64();
//            result.insert("avatarData", base64Data);
//            /*
//                返回的json格式
//                type returnUserInfo
//                status
//                uid
//                nickname
//                avatarName
//                avatarData
//            */
//        }
//        //TODO文件未找到
//    }
//    //TODO数据库查询失败
//
//    //构造并回传消息
//    //QJsonDocument doc(result);
//    msgReply(socket, doc.toJson(), noFile);
//
//}
//
//void Process::msgReply(QTcpSocket* socket, const QByteArray& data, int type = 1)
//{
//    if (!socket || !socket->isOpen())
//        return;
//
//    QByteArray block;
//    QDataStream out(&block, QIODevice::WriteOnly);
//    out.setVersion(QDataStream::Qt_6_3);
//
//    out << (qint64)(data.size() + sizeof(int)); // 总长度（payload + type）
//    out << type;                                // 消息类型
//    block.append(data);                         // 消息体
//
//    //发送
//    socket->write(block);
//    socket->flush(); // 确保立即发送到网络缓冲区
//}
