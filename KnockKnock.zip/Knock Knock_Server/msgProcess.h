﻿//#ifndef MSG_PROCESS_H
//#define MSG_PROCESS_H
//
//#include <QObject>
//
//class QJsonValue;
//class QTcpSocket;
//class DataBase;
//
//class Process : public QObject
//{
//	Q_OBJECT
//
//public:
//	explicit Process(QObject* parent = nullptr);
//	~Process();
//
//	//QMap<QString, QTcpSocket*> clientList;	//维护所有在线客户端的列表
//
//	void msgProcess(QTcpSocket* socket, const QByteArray& data);
//	void msgReply(QTcpSocket* socket, const QByteArray& data, int type);
//	QJsonObject converToJson(const QByteArray& data);			//QByteArray转为Json
//	QByteArray converToByteArray(const QJsonObject& data);	//Json转为QByteArray格式
//
//private:
//	DataBase* database;
//
//private:
//	void registerUser(QTcpSocket* socket, const QJsonObject& dataValue);
//	void login(QTcpSocket* socket, const QJsonObject& dataValue);
//	void searchUser(QTcpSocket* socket, const QJsonObject& dataValue);
//	void storeFile(QTcpSocket* socket, const QJsonObject& dataValue);
//};
//
//
//#endif // !MSG_PROCESS_H
//
