#include "GroupList.h"

GroupList::GroupList(QWidget* parent)
{
	this->setFixedWidth(250);
	this->setStyleSheet("border:none;");
	this->setStyleSheet("background-color:#ccffff;");
	InitWidget();
}
GroupList::~GroupList()
{}

void GroupList::InitWidget()
{

}
