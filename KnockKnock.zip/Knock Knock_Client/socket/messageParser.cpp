﻿#include "MessageParser.h"
//#include "networkManager.h"
#include "../util/util.h"

#include <QDir>
#include <QJsonObject>

MessageParser::MessageParser(QObject* parent) : QObject(parent)
{
	//connect(NetworkManager::getInstance(), &NetworkManager::jsonReceived, [this](const QByteArray& data) {
	//	MessageProcess(converToJson(data));
	//	});
}

//解包传来的消息
void MessageParser::MessageProcess(const QJsonObject& data)
{
	int msg_type = -1;
	msg_type = data.value("type").toInt();

	switch (msg_type)
	{
	case Register:
	{
		//NetworkManager::getInstance()->sendPacket(converToByteArray(data), noFile);
	}	break;
	case Login:
	{
		//NetworkManager::getInstance()->sendPacket(converToByteArray(data), noFile);
	}	break;
	case LoginResult:
	{
		emit msgReturn(data);
	}	break;
	case RegisterResult:
	{
		emit msgReturn(data);
	}	break;
	default:
		break;
	}
}

//void MessageParser::RegisterUser(const QJsonObject& data)
//{
//	
//	QFile file(data.value("avatarPath").toString());
//	if (!file.open(QIODevice::ReadOnly))	//打开失败
//		return;
//	QByteArray fileData = file.readAll();
//	file.close();
//
//	//构造文件传输协议头
//	QJsonObject header;
//	header.insert("type", FILE);
//	header.insert("uid", data.value("uid").toString());
//
//	
//}

MessageParser::~MessageParser()
{
}

//void MessageParser::msgMessageParser(const QJsonObject& data)
//{
//	int msg_type = -1;
//	msg_type = data.value("type").toInt();
//	switch (msg_type)
//	{
//	case Register:
//	{
//
//		emit sendMessage(converToByteArray(data));		//发送给tcpClient
//
//	} break;
//	case RegisterResult:
//	{
//		emit msgReturn(converToByteArray(data));
//	} break;
//	case Login:
//	{
//		emit sendMessage(converToByteArray(data));
//
//	}	break;
//	case LoginResult:
//	{
//		emit msgReturn(converToByteArray(data));
//	}	break;
//	//case File:
//	//{
//	//	emit sendMessage(converToByteArray(data));
//	//}	break;
//	case returnUserInfo:
//	{
//		signalSearchResult(data);
//	}	break;
//	default:
//		break;
//	}
//
//}
//void MessageParser::(int type, const QString& filePath, const QString& uid)
//{
//	QJsonObject header;
//	header.insert("type", type);
//	header.insert("uid", uid);
//
//	if (type == Upload)
//	{
//		QFile file(filePath);
//		if (!file.open(QIODevice::ReadOnly))
//			return;
//
//		QByteArray fileData = file.readAll();
//		file.close();
//
//		header.insert("fileName", QFileInfo(filePath).fileName());
//		header.insert("size", fileData.size());
//
//		QByteArray headerData = converToByteArray(header);
//
//		QByteArray sendData;
//		QDataStream stream(&sendData, QIODevice::WriteOnly);
//		stream.setByteOrder(QDataStream::BigEndian);
//
//		stream << (qint32)headerData.size();
//		sendData.append(headerData);
//		sendData.append(fileData);
//
//		emit sendMessage(sendData);
//	}
//	else if (type == Download)
//	{
//		header.insert("fileName", QFileInfo(filePath).fileName());
//		header.insert("size", 0);
//
//		QByteArray headerData = converToByteArray(header);
//
//		QByteArray sendData;
//		QDataStream stream(&sendData, QIODevice::WriteOnly);
//		stream.setByteOrder(QDataStream::BigEndian);
//		stream << (qint32)headerData.size();
//		sendData.append(headerData);
//
//		emit sendMessage(sendData);
//	}
//
//
//
//
//
//	QFile file(filePath);
//	if (!file.open(QIODevice::ReadOnly))
//		return;
//
//	QByteArray fileData = file.readAll();
//	file.close();
//
//	QJsonObject header;
//	header.insert("type", FILE);
//	header.insert("category", 1);	//TODO添加类别定义
//	header.insert("uid", uid);
//	header.insert("fileName", QFileInfo(filePath).fileName());
//	header.insert("size", fileData.size());
//
//	QByteArray headerData = converToByteArray(header);
//	QByteArray sendData;
//	QDataStream stream(&sendData, QIODevice::WriteOnly);
//	stream.setByteOrder(QDataStream::BigEndian);
//	stream << (qint32)headerData.size();	//长度
//	sendData.append(headerData);			//头部
//	sendData.append(fileData);				//数据
//
//	emit sendMessage(sendData);
//}
//void MessageParser::searchUser(QString uid)
//{
//	QJsonObject json;
//	json.insert("type", searchUserInfo);
//	json.insert("uid", uid);
//	emit sendMessage(converToByteArray(json));
//}
