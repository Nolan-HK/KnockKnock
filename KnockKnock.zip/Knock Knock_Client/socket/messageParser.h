﻿#ifndef MESSAGEPARSER_H
#define MESSAGEPARSER_H

#include <QObject>

class QJsonObject;
class QByteArray;
class NetworkManager;

class MessageParser : public QObject
{
	Q_OBJECT

signals:
	void msgReturn(const QJsonObject& data);
	void sendMessage(const QByteArray& data);
	void connectStatus(const QString& status);
	void signalSearchResult(const QJsonObject& data);


public:
	explicit MessageParser(QObject* parent = nullptr);
	~MessageParser();


	void MessageProcess(const QJsonObject& data);
	void FileProcess(int type, const QString& filePath, const QString& uid);	//类型：上传/下载
	void searchUser(QString uid);

	QJsonObject converToJson(const QByteArray& data);			//QByteArray转为Json格式
	QByteArray converToByteArray(const QJsonObject& data);	//Json转为QByteArray格式

private:


	void RegisterUser(const QJsonObject& data);

};


#endif // !MSG_MessageParser_H

